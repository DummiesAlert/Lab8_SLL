﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_SLL
{
    internal class LinkedList
    {

        public Node Head { get; set; }
        public Node Tail{ get; set; }

        public int Count { get; set; }

        public LinkedList()

        {

            this.Head = null;
            this.Tail = null;

        }

        public void AddFirst(string Value) 

        {

            Node nodeNode = new Node();
            nodeNode.Value = Value;

            if (Head == null)

                Head = Tail = nodeNode;

            else

            {

                nodeNode.Next = Head;
                Head = nodeNode;

            }

            Count++;
            
        }

        public void AddLast(string Value) 
        {
            Node nodeNode = new Node();
            nodeNode.Value = Value;

            if (Head == null) 

                Tail = Head = nodeNode;

            else

            {

                Tail.Next = nodeNode;
                Tail = nodeNode;

            }

            Count++;
        }

        public void RemoveFirst() 

        {

            if ((Head == Tail) && Tail == null)

                throw new Exception("LinkedList is EMPTY");

            else if ((Head == Tail) && Tail != null)

            {

                Head = null;
                Tail = null;

            }

            else 

            {

                Node newHead = Head.Next;
                Head.Next = null;
                Head = newHead;

            }

            Count--;

        }

        public void RemoveLast() 
        {
            if ((Head == Tail) && Tail == null)

                throw new Exception("LinkedList is EMPTY");

            else if ((Head == Tail) && Tail != null)

            {

                Head = null;
                Tail = null;

            }

            else 

            {
                
                Node Current = Head;

                while (Current != null) 

                {

                    if (Current.Next == Tail) 

                    {

                        Tail = Current;
                        Current.Next = null;
                        break;

                    }

                    Current = Current.Next;
                }
            }

            Count--;
        }

        public string GetValue(int Ind) 

        {

            int nodeIndex = 0;

            Node Current = Head;

            while (Current != null) 

            {
                
                if (nodeIndex == Ind)

                    return Current.Value;

                nodeIndex++;
                Current = Current.Next;

            }

            return "NOT FOUND";

        }

        public int Size() 

        {

            if ((Head == Tail) && Tail == null)

                return 0;

            else if ((Head == Tail) && Tail != null)

                return 1;

            else 

            {

                Node Current = Head;

                int Size = 0;

                while (Current != null)

                {

                    Size++;
                    Current = Current.Next;
                    
                }

                return Size;
            }
        }

    }
}