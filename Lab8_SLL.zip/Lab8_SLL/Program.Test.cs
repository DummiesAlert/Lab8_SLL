using NUnit.Framework;
using System.Reflection.Metadata;

namespace Lab8_SLL
{
    public class Tests
    {
        private LinkedList SLL;

        [SetUp]
        public void Setup()

        {

            string[] Names = new[] { "Joe Blow", "Joe Schmoe", "John Smith", "Jane Doe", "Bob Bobberson", "Sam Sammerson", "Dave Daverson"};
            
            SLL = new LinkedList();

            foreach (string Name in Names)

                SLL.AddLast(Name);

        }

        [Test]
        public void TestAddFirst()

        {

            SLL.AddFirst("Henry Bigg");
            
            string aclHead = "Henry Bigg";
            string expdHead = SLL.Head.Value;
            
            Assert.AreEqual(expdHead, aclHead);

            string aclNext = "Joe Blow";
            string expdNext = SLL.Head.Next.Value;
            
            Assert.AreEqual(expdNext, aclNext);

        }

        [Test]
        public void TestAddLast() 

        {

            Node lastTail = SLL.Tail;
            SLL.AddLast("Doug Highh");
            
            string aclTail = SLL.Tail.Value;
            string expdTail = "Doug Highh";
            
            Assert.AreEqual(expdTail, aclTail);

            string aclLastTail = lastTail.Value;
            string expdLastTail = "Dave Daverson";
            
            Assert.AreEqual(expdLastTail, aclLastTail);

        }

        [Test]
        public void TestRemoveFirst() 

        {

            SLL.RemoveFirst();
            
            string aclHead = SLL.Head.Value;
            string expdHead = "Joe Schmoe";
            
            Assert.AreEqual(expdHead, aclHead);

        }

        [Test]
        public void TestRemoveLast()

        {

            SLL.RemoveLast();
            
            string aclTail = SLL.Tail.Value;
            string expdTail = "Sam Sammerson";
            
            Assert.AreEqual(expdTail, aclTail);

        }

        [Test]
        public void TestGetValue()
        {
            string aclValue = SLL.GetValue(3);
            string expdValue = "Bob Bobberson";
            
            Assert.AreEqual(expdValue, aclValue);
        }

        [Test]
        public void TestSize()
        {
            int aclSize = SLL.Count;
            int expdSize = 7;
            
            Assert.AreEqual(expdSize, aclSize);
        }

        [TearDown]
        public void Teardown()
        {
            SLL.Head = null;
            SLL.Tail = null;
            SLL = null;
        }    
    }
}