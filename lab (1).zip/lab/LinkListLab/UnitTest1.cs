using NUnit.Framework;
using System.Reflection.Metadata;

namespace LinkListLab
{
    public class Tests
    {
        private LinkedList sll;
        [SetUp]
        public void Setup()
        {
            string[] names = new[] { "Joe Blow", "Joe Schmoe", "John Smith", "Jane Doe", "Bob Bobberson", "Sam Sammerson", "Dave Daverson" };
            sll = new LinkedList();
            foreach (string name in names)
                sll.AddLast(name);
        }

        [Test]
        public void TestAddFirst()
        {
            sll.AddFirst("John Dao");
            string actualHead = "John Dao";
            string expectedHead = sll.Head.Value;
            Assert.AreEqual(expectedHead, actualHead);

            string actualNext = "Joe Blow";
            string expectedNext = sll.Head.Next.Value;
            Assert.AreEqual(expectedNext, actualNext);

        }

        [Test]
        public void TestAddLast() 
        {
            Node previousTail = sll.Tail;
            sll.AddLast("Gordon Hong");
            string actualTail = sll.Tail.Value;
            string expectedTail = "Gordon Hong";
            Assert.AreEqual(expectedTail, actualTail);

            string actualPreviousTail = previousTail.Value;
            string expectedPreviousTail = "Dave Daverson";
            Assert.AreEqual(expectedPreviousTail, actualPreviousTail);
        }

        [Test]
        public void TestRemoveFirst() 
        {
            sll.RemoveFirst();
            string actualHead = sll.Head.Value;
            string expectedHead = "Joe Schmoe";
            Assert.AreEqual(expectedHead, actualHead);
        }

        [Test]
        public void TestRemoveLast()
        {
            sll.RemoveLast();
            string actualTail = sll.Tail.Value;
            string expectedTail = "Sam Sammerson";
            Assert.AreEqual(expectedTail, actualTail);
        }

        [Test]
        public void TestGetValue()
        {
            string actualValue = sll.GetValue(3);
            string expectedValue = "Jane Doe";
            Assert.AreEqual(expectedValue, actualValue);
        }

        [Test]
        public void TestSize()
        {
            int actualSize = sll.Count;
            int expectedSize = 7;
            Assert.AreEqual(expectedSize, actualSize);
        }

        [TearDown]
        public void Teardown()
        {
            sll.Head = null;
            sll.Tail = null;
            sll = null;
        }    
    }
}