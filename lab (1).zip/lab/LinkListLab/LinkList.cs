﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkListLab
{
    internal class LinkedList
    {

        public Node Head { get; set; }
        public Node Tail{ get; set; }

        public int Count { get; set; }

        public LinkedList()
        {
            this.Head = null;
            this.Tail= null;
        }

        public void AddFirst(string Value) 
        {

            Node  node = new Node();
            node.Value = Value;
            if (Head == null)
                Head = Tail = node;
            else 
            {
                node.Next = Head;
                Head = node;
            }
            Count++;
        }
        public void AddLast(string Value) 
        {
            Node node = new Node();
            node.Value = Value;

            if (Head == null) 
                Tail = Head = node;

            else
            {
                Tail.Next = node;
                Tail = node;
            }
            Count++;
        }
        public string GetValue(int index) 
        {
            int nodeIndex = 0;
            Node current = Head;
            while (current != null) 
            {
                if (nodeIndex == index)
                    return current.Value;
                nodeIndex++;
                current = current.Next;
            }
            return "not found";
        }
        
        public void RemoveFirst() 
        {
            if ((Head == Tail) && Tail == null)
                throw new Exception("LinkedList is empty");

            else if ((Head == Tail) && Tail != null)
            {
                Head = null;
                Tail = null;
            }

            else 
            {
                Node newHead = Head.Next;
                Head.Next = null;
                Head = newHead;
            }
            Count--;
        }
        public void RemoveLast() 
        {
            if ((Head == Tail) && Tail == null)
                throw new Exception("LinkedList is empty");

            else if ((Head == Tail) && Tail != null)
            {
                Head = null;
                Tail = null;
            }
            else 
            {
                Node current = Head;
                while (current != null) 
                {
                    if (current.Next == Tail) 
                    {
                        Tail= current;
                        current.Next = null;
                        break;
                    }
                    current = current.Next;
                }
            }
            Count--;
        }

        public int Size() 
        {
            if ((Head == Tail) && Tail == null)
                return 0;

            else if ((Head == Tail) && Tail != null)
                return 1;
            else 
            {
                Node current = Head;
                int size = 0;
                while (current != null)
                {
                    size++;
                    current = current.Next;
                }
                return size;
            }
        }

    }
}
